%addpath([pwd '/']);
%addpath([pwd '/MEX/']);
%display('Loading the default parameters ...');
params = defaultParams(objectness_dir);
